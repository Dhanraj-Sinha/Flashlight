An Light is a useful flashlight,It quickly and easily turns on the flashlight.

## Feature
<ol>
<li>Quick start</li>
<li>The flashlight work when the screen is off</li>
<li>Screen Flashlight</li>
<li>Screen Home Widget</li>
<li>Built-in SOS flashlight signal</li>
<li>Strobe mode</li>
<li>Support Morse Code</li>
</ol>

[<img src="https://fdroid.gitlab.io/artwork/badge/get-it-on.png"
     alt="Get it on F-Droid"
     height="80">](https://f-droid.org/packages/com.series.anlight/)
[<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png"
     alt="Get it on Google Play"
     height="80">](https://play.google.com/store/apps/details?id=com.series.anlight)

<img src="fastlane/metadata/android/en-US/images/phoneScreenshots/01.png" width="250"/> <img src="fastlane/metadata/android/en-US/images/phoneScreenshots/02.png" width="250"/>
<img src="fastlane/metadata/android/en-US/images/phoneScreenshots/03.png" width="250"/>

package com.series.anlight


const val BRIGHT_DISPLAY = "bright_display"
const val BRIGHT_COLOR = "bright_color"
const val FLASH = "flash_on"
const val STROBOSCOPE = "stroboscope"
const val SOS = "sos"
const val MORSE = "... --- ..."
